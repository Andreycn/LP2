﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcalcIMC
{
    public partial class frmCalcIMC : Form
    {
        double peso, altura, resultadoIMC, grau;
        string classificacao;
        public frmCalcIMC()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            resultadoIMC = peso / (Math.Pow(altura, 2));
            resultadoIMC = Math.Round(resultadoIMC,2);
            txtIMC.Text = Convert.ToString(resultadoIMC);

            if (resultadoIMC < 18.5)
            {
                txtClassificacao.Text = "MAGREZA";
                txtGrau.Text = "Grau 0";
            }
            else if (resultadoIMC <= 24.9)
            {
                txtClassificacao.Text = "NORMAL";
                txtGrau.Text = "Grau 0";
            }
            else if (resultadoIMC <= 29.9)
            {
                txtClassificacao.Text = "SOBREPESO";
                txtGrau.Text = "Grau 1";
            }
            else if (resultadoIMC <= 39.9)
            {
                txtClassificacao.Text = "OBESIDADE";
                txtGrau.Text = "Grau 2";
            }
            else
            {
                txtClassificacao.Text = "OBESIDADE GRAVE";
                txtGrau.Text = "Grau 3";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmCalcIMC_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
            txtClassificacao.Clear();
            txtGrau.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso) || peso <= 0 || peso >= 500)
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura) || altura <= 0 || altura >= 250)
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
