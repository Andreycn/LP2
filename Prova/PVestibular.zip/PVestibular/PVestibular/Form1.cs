﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class frmVestibular : Form
    {
        public frmVestibular()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReceber_Click_1(object sender, EventArgs e)
        {
            int[,] cursoAnos = new int[3, 5];
            int totalCurso = 0;
            int totalGeral = 0;
            string auxiliar;

            for (int i = 0; i < cursoAnos.GetLength(0); i++)
            {
                for (int j = 0; j < cursoAnos.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o total de alunos do curso {i + 1} do ano {j + 1}", "Entrada de dados");

                    if (!int.TryParse(auxiliar, out cursoAnos[i, j]))
                    {
                        MessageBox.Show("Número de Alunos Inválido");
                        j--;
                    }
                    else if (cursoAnos[i, j] < 0 || auxiliar == " ")
                    {
                        MessageBox.Show("Número de Alunos Inválido");
                        j--;
                    }
                    else
                    {
                        lstbTotal.Items.Add($"Total do curso {i + 1} do ano {j + 1}  : {cursoAnos[i, j]}");
                        totalCurso += cursoAnos[i, j];
                    }
                    
                }
                lstbTotal.Items.Add($"_______________________");
                lstbTotal.Items.Add("Total do curso " + (i + 1)  + ": " + totalCurso);

                totalGeral += totalCurso;
                totalCurso = 0;
            }

            lstbTotal.Items.Add($"_______________________");
            lstbTotal.Items.Add($"Total Geral: {totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbTotal.Items.Clear();
        }
    }
}
